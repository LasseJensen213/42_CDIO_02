package game;

public class Game {
	
	private Player playerArr[];
	
	public void play()
	{
		//Lets go
	}

}
